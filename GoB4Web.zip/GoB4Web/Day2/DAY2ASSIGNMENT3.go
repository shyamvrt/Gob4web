package main
import "fmt"

func main() {
    var a [5] int
   var highest,lowest int
   fmt.Println("enter the Salary of 5 employees")
   for i:=0;i<5;i++ {
    fmt.Scanln(&a[i])

}
    highest,lowest=fun(a)
    fmt.Println(highest,lowest)
   }
   
   func fun(n[5] int) int{
    for i:=0;i<5;i++ {
        for j:=i+1;j<5;j++ {
            if(n[i]<n[j]) {
                temp:=n[i]
                n[i]=n[j]
                n[j]=temp
            }
        }
    }
    h:=n[0]
    l:=n[4]
    return h,l
   } 