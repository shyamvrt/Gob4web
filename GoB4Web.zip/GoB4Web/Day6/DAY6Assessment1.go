package main
import "fmt"
type customer struct {  
                name string  
                address string
}  

func main() {
                telephoneDirectory:=make( map[float64]customer)
                //fmt.Println(telephoneDirectory)
                telephoneDirectory[9962230703] = customer{"Shyam","Chennai"}
    telephoneDirectory[9341056259] =  customer{"TRV","Banglore"}
                telephoneDirectory[9175325501] =  customer{"Devi","Hyderabad"}
                telephoneDirectory[8807590361] =  customer{"Santhosh","Amaravathi"}
                
                fmt.Println("Enter the telephone number to be found")
                
                var search float64
                fmt.Scanln(&search)

                value, ok := telephoneDirectory[search]

                if ok==true {
        fmt.Println("Address of", search, "is", value)
    } else {
        fmt.Println("Address of", search,"is not found")
    }


                }