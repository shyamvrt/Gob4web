package main
import "fmt"

type employee struct{
	name string
	desg string
	sal int
	v vehicle
}

type vehicle[] string

type movies struct {
	language string
	releaseDate string
	director string
	producer string
	duration int
}
func main() {
	
	//Oues 1
	//   var c=map[int]employee { 1:employee{"a","PA",25000,vehicle{"duke","honda"},},
	//   2:employee{"b","PA",25000,vehicle{"r15","skoda"},},
	//   3:employee{"c","PA",25000,vehicle{"ninja"},},}
	//   for _,value:= range c {
	// 		fmt.Println(value.name,value.desg,value.sal,value.v,"\n")
	// 	}

	//Oues 2
	var m=map[string]movies {"MA": movies{"English","10/10/2015","Speilsberg","Richie Rich",120},
	"MB": movies{"English","10/10/2016","Speilsberg","Richie Rich",120},
	"MC": movies{"English","10/10/2017","Speilsberg","Richie Rich",120},
	"MD": movies{"English","10/10/2018","Speilsberg","Richie Rich",120}}
	for _,value:= range m {
		fmt.Println(value.language,value.releaseDate,value.director,value.producer,value.duration,"\n")
	}
	var mov string
	fmt.Print("Enter movie to delete: ")
	fmt.Scanln(&mov)
	delete(m, mov)  
	for _,value:= range m {
		fmt.Println(value.language,value.releaseDate,value.director,value.producer,value.duration,"\n")
	}
}